using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Game.Inputs
{
    [RequireComponent(typeof(Rigidbody))]
    public class PlayerMovement : MonoBehaviour
    {
        [SerializeField, Range(0f, 10f)] private float playerMoveSpeed = 4.0f;
        [SerializeField, Range(-10f, 0f)] private float playerWeight = (-0.5f);
        [SerializeField] private Rigidbody playerRigidbody;
        public void MoveCharacter(Vector3 movement)
        {
            playerRigidbody.velocity = (movement * playerMoveSpeed + transform.up * playerWeight);
        }

#if UNITY_EDITOR
        [ContextMenu("Reset values")]
        public void ResetValue()
        {
            playerMoveSpeed = 4.0f;
        }
#endif
    }
}
