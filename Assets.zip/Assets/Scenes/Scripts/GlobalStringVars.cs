namespace Game.Inputs
{
    public class GlobalStringVars
    {
        public const string HORIZONTAL_AXIS = "Horizontal";
        public const string VERTICAL_AXIS = "Vertical";
        public const string JUMP_BUTTON = "Jump";

        public const string MOUSE_X_AXIS = "Mouse X";
        public const string MOUSE_Y_AXIS = "Mouse Y";

        public const string MOUSE_BUTTON_0 = "Fire1";
    }
}

