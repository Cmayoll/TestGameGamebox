using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletRule : MonoBehaviour
{
    [SerializeField, Range(0, 100)] private int ShootDamage = 100;
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Enemy"))
            other.gameObject.GetComponent<SculllMovement>().GetDamage(ShootDamage);

        if (other.CompareTag("Ground"))
            Destroy(gameObject); 
    }
}
