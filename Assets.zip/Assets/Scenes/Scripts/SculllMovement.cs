using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;

public class SculllMovement : MonoBehaviour
{
    private Transform playerTransform;
    private Transform enemyTransform;
    public int HealthPoint = 100;

    [SerializeField] private GameObject Villager1;
    [SerializeField] private GameObject Villager2;
    [SerializeField] private GameObject Villager3;
    [SerializeField] private GameObject Villager4;
    [SerializeField] private GameObject Villager5;
    private List<GameObject> numberOfVillagers = new List<GameObject>();

    public void GetDamage(int damageNumber)
    {
        HealthPoint -= damageNumber;
        if (HealthPoint <= 0)
        {
            BecomeVillager();
        }
    }
    private void Start()
    {
        enemyTransform = GetComponent<Transform>();
        numberOfVillagers =  new List<GameObject>{ Villager1, Villager2, Villager3, Villager4, Villager5 };
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
    }
    private void Update()
    {
        enemyTransform.LookAt(new Vector3(playerTransform.position.x, enemyTransform.position.y, playerTransform.position.z));
    }

    // ��������� ������ ����� �����������
    public void BecomeVillager()
    {
        int chooseVillager = Random.Range(0, 5);
        Instantiate(numberOfVillagers[chooseVillager],new Vector3(enemyTransform.position.x, enemyTransform.position.y - (enemyTransform.position.y - numberOfVillagers[chooseVillager].transform.position.y), enemyTransform.position.z),enemyTransform.rotation);
        Destroy(enemyTransform.gameObject);
    }
}
