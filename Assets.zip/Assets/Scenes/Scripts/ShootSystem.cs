using Game.Inputs;
using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class ShootSystem : MonoBehaviour
{
    [SerializeField] private GameObject bullet;
    [SerializeField] private GameObject absorbSphere;

    [SerializeField, Range(0f, 100f)] private float ShootForce = 15f;
    [SerializeField, Range(0f, 1f)] private float verticalShootForce = 1f;
    [SerializeField, Range(0f, 100f)] private float ShootMaxDistance = 20f;


    void Update()
    {
        if (GameObject.FindGameObjectWithTag("Bullet") != null)
        {
            Vector3 bulletDistance = GameObject.FindGameObjectWithTag("Player").transform.position - GameObject.FindGameObjectWithTag("Bullet").transform.position;
            if (Mathf.Pow(bulletDistance.x * bulletDistance.x + bulletDistance.y * bulletDistance.y + bulletDistance.z * bulletDistance.z, 0.5f) > ShootMaxDistance)
            {
                GameObject.Destroy(GameObject.FindGameObjectWithTag("Bullet"));
            }
        }
    }

    public void ShootBullet()
    {
        if (GameObject.FindGameObjectWithTag("Bullet") == null && GetComponent<PlayerImput>().MANA > 0)
        {
            Transform playerTransform = GameObject.FindGameObjectWithTag("Player").transform;

            Instantiate(bullet, playerTransform.position, Quaternion.identity);

            Vector3 ShotDirection = (playerTransform.forward + Vector3.up * verticalShootForce).normalized;

            GameObject.FindGameObjectWithTag("Bullet").GetComponent<Rigidbody>().AddForce(ShotDirection * ShootForce, ForceMode.Impulse);


            GetComponent<PlayerImput>().MANA -= 10;
        }

    }

}
