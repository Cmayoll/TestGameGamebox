using Game.Inputs;
using UnityEngine;

public class AbsorbTheJoy : MonoBehaviour
{
    public bool absorb;
    private GameObject player;
    [SerializeField, Range(0f, 10f)] private float shareSpeed = 0.00000000001f;

    private void Start()
    {
        absorb = false;
        player = GameObject.FindGameObjectWithTag("Player");
    }

    private void Update()
    {
        // ���������� ����

        if (absorb && player.GetComponent<PlayerImput>().MANA < 100)
        {
            player.GetComponent<PlayerImput>().MANA += shareSpeed;
        }
    }


    // �������� �� ������� ������� � �����

    private void OnTriggerStay(Collider other)
    {
        if (other.CompareTag("Villager"))
            absorb = true;
    }
    private void OnTriggerExit(Collider other)
    {
        if (other.CompareTag("Villager"))
            absorb = false;
    }
}
