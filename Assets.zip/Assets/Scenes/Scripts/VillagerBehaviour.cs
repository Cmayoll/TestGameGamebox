using UnityEngine;

public class VillagerBehaviour : MonoBehaviour
{
    private Transform playerTransform;
    private Transform villagerTransform;

    private bool IsAbsorb;

    private void Start()
    {
        villagerTransform = GetComponent<Transform>();
        playerTransform = GameObject.FindGameObjectWithTag("Player").transform;
    }
    void Update()
    {
        villagerTransform.LookAt(playerTransform);
    } 
}
