using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace Game.Inputs
{
    [RequireComponent(typeof(PlayerMovement))]
    public class PlayerImput : MonoBehaviour
    {
        private PlayerMovement playerMovement;
        private ShootSystem shootSystem;

        private Vector3 movement;

        [SerializeField] private Animator playerAnimator;
        [SerializeField] private GameObject absorbSphere; 

        [SerializeField] private Image manaBar;
        [SerializeField] private GameObject gameOverScreen;

        public float MANA = 100f;

        private void Awake()
        {
            playerMovement = GetComponent<PlayerMovement>();
            shootSystem = GetComponent<ShootSystem>();
        }
        void Update()
        {
            // �������������� ����������
            float horisontal = Input.GetAxis(GlobalStringVars.HORIZONTAL_AXIS);
            float vertical = Input.GetAxis(GlobalStringVars.VERTICAL_AXIS);
            movement = transform.right * horisontal + transform.forward * vertical;

            playerAnimator.SetFloat("HorizontalAxisAcive", Mathf.Max(Mathf.Abs(GetComponent<Rigidbody>().velocity.x), Mathf.Abs(GetComponent<Rigidbody>().velocity.z)));
            
            // �������� ���
            if (Input.GetKey(KeyCode.Mouse0))
                shootSystem.ShootBullet();

            
            //���������� ���� ���
            if (Input.GetKey(KeyCode.Mouse1))
                absorbSphere.SetActive(true);
            if (Input.GetKeyUp(KeyCode.Mouse1))
            {
                absorbSphere.GetComponent<AbsorbTheJoy>().absorb = false;
                absorbSphere.SetActive(false);
            }

            // ������� ������
            if (MANA <= 0)
            {
                Time.timeScale = 0;
                gameOverScreen.SetActive(true);
            }

            // ��������� ����
            manaBar.fillAmount = MANA / 100;
        }

        private void FixedUpdate()
        {
            playerMovement.MoveCharacter(movement);
        }

        // ���������� ������
        public void Restart()
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}

